<?php
/**
 * SAARTHI Backend - WhatsApp Service
 * Handles WhatsApp message sending via CallMeBot or similar gateway
 */

class WhatsAppService {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    /**
     * Send WhatsApp message
     * @param string $phoneNumber Phone number with country code (e.g., +919876543210)
     * @param string $message Message text
     * @param int $userId User ID for logging
     * @param int|null $eventId Event ID if triggered by event
     */
    public function sendMessage($phoneNumber, $message, $userId, $eventId = null) {
        // Clean phone number (remove + and spaces)
        $phoneNumber = preg_replace('/[^0-9]/', '', $phoneNumber);
        
        // CallMeBot API format
        // https://api.callmebot.com/whatsapp.php?phone=+919876543210&text=Hello&apikey=YOUR_KEY
        $url = WHATSAPP_API_URL . '?' . http_build_query([
            'phone' => '+' . $phoneNumber,
            'text' => urlencode($message),
            'apikey' => WHATSAPP_API_KEY
        ]);

        // Alternative: Using instance-based API
        // $url = "https://api.green-api.com/waInstance" . WHATSAPP_INSTANCE_ID . "/sendMessage/" . WHATSAPP_API_KEY;
        // Use POST with JSON body for instance-based APIs

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        $status = ($httpCode == 200 && !$error) ? 'SENT' : 'FAILED';
        $responseData = $response ?: $error;

        // Log notification
        $stmt = $this->db->prepare("
            INSERT INTO notification_logs (user_id, event_id, target_phone, channel, message, status, response_data, sent_at)
            VALUES (?, ?, ?, 'WHATSAPP', ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $userId,
            $eventId,
            '+' . $phoneNumber,
            $message,
            $status,
            $responseData
        ]);

        return $status === 'SENT';
    }

    /**
     * Send alert with location link
     */
    public function sendAlert($phoneNumber, $userName, $eventType, $latitude = null, $longitude = null, $userId = null, $eventId = null) {
        $message = "🚨 SAARTHI Safety Alert\n\n";
        $message .= "User: " . $userName . "\n";
        $message .= "Event: " . $eventType . "\n";
        $message .= "Time: " . date('d M Y, h:i A') . "\n";
        
        if ($latitude && $longitude) {
            $mapsUrl = "https://www.google.com/maps?q=" . $latitude . "," . $longitude;
            $message .= "📍 Location: " . $mapsUrl . "\n";
        }
        
        $message .= "\nPlease check the SAARTHI app for details.";
        
        return $this->sendMessage($phoneNumber, $message, $userId, $eventId);
    }
}

