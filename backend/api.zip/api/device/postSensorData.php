<?php
/**
 * SAARTHI Backend - Post Sensor Data API
 * POST /api/device/postSensorData
 * Called by ESP32-CAM to send sensor readings
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../services/whatsapp_service.php';
require_once __DIR__ . '/../../services/geofence_service.php';

$db = (new Database())->getConnection();

// Accept both GET (for ESP32 simplicity) and POST
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = $_GET;
} else {
    $data = getRequestBody();
}

// Required: device_id, user_id (optional, can be derived from device_id)
validateRequired($data, ['device_id']);

$deviceId = $data['device_id'];
$distance = floatval($data['distance'] ?? -1);
$touch = intval($data['touch'] ?? 0);
$micRaw = intval($data['mic'] ?? 0);
$userId = $data['user_id'] ?? null;

// Get device info
$stmt = $db->prepare("SELECT id, user_id, status FROM devices WHERE device_id = ?");
$stmt->execute([$deviceId]);
$device = $stmt->fetch();

if (!$device) {
    sendResponse(false, "Device not found. Please register device first.", null, 404);
}

$userId = $userId ?? $device['user_id'];
$deviceDbId = $device['id'];

// Update device last_seen
$stmt = $db->prepare("UPDATE devices SET last_seen = NOW(), status = 'ONLINE' WHERE id = ?");
$stmt->execute([$deviceDbId]);

// Get sensor thresholds
$stmt = $db->prepare("
    SELECT ultrasonic_min_distance, mic_loud_threshold, night_mode_enabled
    FROM sensor_thresholds
    WHERE user_id = ? AND (device_id = ? OR device_id IS NULL)
    ORDER BY device_id DESC
    LIMIT 1
");
$stmt->execute([$userId, $deviceDbId]);
$thresholds = $stmt->fetch() ?: [
    'ultrasonic_min_distance' => 30.0,
    'mic_loud_threshold' => 2000,
    'night_mode_enabled' => false
];

$eventType = null;
$severity = 'LOW';
$sensorPayload = json_encode([
    'distance' => $distance,
    'touch' => $touch,
    'mic_raw' => $micRaw,
    'timestamp' => date('Y-m-d H:i:s')
]);

// Check for obstacles
if ($distance > 0 && $distance < $thresholds['ultrasonic_min_distance']) {
    $eventType = 'OBSTACLE_ALERT';
    $severity = ($distance < 15) ? 'HIGH' : 'MEDIUM';
}

// Check for loud sounds
if ($micRaw > $thresholds['mic_loud_threshold']) {
    $eventType = 'LOUD_SOUND_ALERT';
    $severity = ($micRaw > 3500) ? 'HIGH' : 'MEDIUM';
}

// Check for touch (SOS)
if ($touch == 1) {
    $eventType = 'SOS_TOUCH';
    $severity = 'CRITICAL';
}

// Store event if detected
if ($eventType) {
    $stmt = $db->prepare("
        INSERT INTO sensor_events (user_id, device_id, event_type, sensor_payload, severity)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$userId, $deviceDbId, $eventType, $sensorPayload, $severity]);
    $eventId = $db->lastInsertId();
    
    // Trigger alerts for critical/high events
    if (in_array($severity, ['HIGH', 'CRITICAL'])) {
        $whatsappService = new WhatsAppService($db);
        $geofenceService = new GeofenceService($db);
        
        // Get user info
        $stmt = $db->prepare("SELECT name, phone FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        // Get latest location
        $stmt = $db->prepare("
            SELECT latitude, longitude FROM locations
            WHERE user_id = ?
            ORDER BY created_at DESC LIMIT 1
        ");
        $stmt->execute([$userId]);
        $location = $stmt->fetch();
        
        // Check geofence
        $geofenceService->checkGeofence($userId, $location['latitude'] ?? null, $location['longitude'] ?? null);
        
        // Send WhatsApp alert
        $message = "🚨 SAARTHI Alert\n\n";
        $message .= "User: " . $user['name'] . "\n";
        $message .= "Event: " . $eventType . "\n";
        $message .= "Severity: " . $severity . "\n";
        $message .= "Time: " . date('Y-m-d H:i:s') . "\n";
        
        if ($location) {
            $mapsUrl = "https://www.google.com/maps?q=" . $location['latitude'] . "," . $location['longitude'];
            $message .= "Location: " . $mapsUrl . "\n";
        }
        
        // Get parent phone numbers
        $stmt = $db->prepare("
            SELECT u.phone FROM users u
            INNER JOIN parent_child_links pcl ON u.id = pcl.parent_id
            WHERE pcl.child_id = ? AND pcl.status = 'ACTIVE'
        ");
        $stmt->execute([$userId]);
        $parents = $stmt->fetchAll();
        
        foreach ($parents as $parent) {
            $whatsappService->sendMessage($parent['phone'], $message, $userId, $eventId);
        }
    }
}

sendResponse(true, "Sensor data received", [
    'event_triggered' => $eventType !== null,
    'event_type' => $eventType,
    'severity' => $severity
], 200);

