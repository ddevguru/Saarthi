    </div>
    <footer style="text-align: center; padding: 20px; color: #666; margin-top: 40px;">
        <p>&copy; <?php echo date('Y'); ?> SAARTHI Admin Panel. All rights reserved.</p>
    </footer>
</body>
</html>

